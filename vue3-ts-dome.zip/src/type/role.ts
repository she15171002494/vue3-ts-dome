export interface ListInt {
  authority: number[]
  roleId: number
  roleName: string
}

export class InitData {
  list: ListInt[] = []
}
